This is a responsive Music Player website made with HTML and CSS.

It has two webpages:

The homescreen - index.html

Single playlist for an artist - single-playlist.html

This is the task given to me during Coding Ninjas Full stack Web Development course.

Features: Click on any artist to open Single playist page which contains details of that artist with all the songs, click on queue on right side on homescreen to open a drop down menu, reduce the screen size to find a banner <<more which displays the queue for low resolutions Home to close the queue and go back to home
